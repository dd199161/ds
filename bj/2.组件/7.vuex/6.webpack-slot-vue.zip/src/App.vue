<template>
    <div>
        <Header>
            <h1 class="title">{{updateTitleNmae}}</h1>
        </Header>
    </div>
</template>
<script>
    import Alert from './components/Alert.vue'
    import Header from './components/Header.vue'
export default {
        //如果不改变名字，那么直接放值就可以，key和value都叫一样的名字
            components:{
                Alert,
                Header
        },
    data : function(){
                return {
                    type : 'success',
                    name : ''
                }
    },
    computed:{
        updateTitleNmae : function(){
            this.name = "张三";
            return this.name;
        }
    }
}
</script>
<style>

</style>