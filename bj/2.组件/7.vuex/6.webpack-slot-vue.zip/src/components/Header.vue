<template>
    <div class="header">
            <slot>

            </slot>
    </div>
</template>
<script>
    export default {
        computed : {

        }
    }
</script>
<style scoped>
 .header{
     position: absolute;
     top: 0;
     left: 0;
     width: 100%;
     background: deepskyblue;
 }
    .title{
        color: #fffadf;
        font-size: 22px;
        text-align: center;
    }
</style>