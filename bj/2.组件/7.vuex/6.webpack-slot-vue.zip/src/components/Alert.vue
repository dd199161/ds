<template>
    <div>
        CODE：
        <div :class="typeClass">
            <slot>
                default
            </slot>
        </div>

    </div>
</template>
<script>
    export default {
        props:['type'],
        computed : {
            typeClass :function(){
                return {
                    'alert-success' : this.type === 'success',
                    'alert-wrn' : this.type === 'wrn',
                    'alert-error' : this.type === 'error'
                }
            }
        }
    }
</script>
<style>
    .alert-success{
        color:green;
    }
    .alert-wrn{
        color:yellow;
    }
    .alert-error{
        color: red;
    }
</style>